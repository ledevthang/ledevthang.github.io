(function (n, t) {
  "use strict";
  if (typeof n == "undefined") return !1;
  n.fn.dropdownLayer = function (i) {
    var u, c, l, a, e, h, v, y, o, r, s, p, f;
    return (
      (u = this),
      (s = 0),
      (f = 0),
      (a = {
        elemSelector: "js-dropdown-item",
        containerClass: "js-dropdown-items",
        descriptionClass: "js-description",
        dropdownClass: "js-dropdown",
        arrowClass: "js-dropdown-arrow",
        dropdownContentClass: "js-dropdown-content",
        disableDropdownClass: "js-dropdown-disable",
        slideUpSpeed: 300,
        slideDownSpeed: 300,
        useSlideDown: !1,
        useSlideUp: !1,
        transitionEffect: "swing",
        callOnCompleteHide: function () {},
        callOnCompleteShow: function () {},
      }),
      (r = n.extend(a, i)),
      (e = function () {
        return (
          (100 * n("." + r.elemSelector).width()) /
          n("." + r.containerClass).width()
        );
      }),
      (h = function (n) {
        s = e() <= 25 ? 3 : e() <= 50 ? 2 : 1;
        typeof n == "function" && n();
      }),
      (v = function (n) {
        f = e() <= 25 ? 3 : e() <= 50 ? 2 : 1;
        typeof n == "function" && n();
      }),
      (p = function () {
        h(function () {
          var t, i;
          f !== 0 &&
            ((i = n("." + r.dropdownClass).detach()),
            (t = u.next()),
            typeof t.position() != "undefined"
              ? i.insertAfter(o(u, t))
              : i.insertAfter(u),
            n("." + r.arrowClass).css(
              "left",
              u.position().left + u.outerWidth() / 2
            ));
        });
      }),
      (c = function () {
        n("." + r.arrowClass).hide();
        r.useSlideUp
          ? n("." + r.dropdownClass).slideUp({
              duration: r.slideUpSpeed,
              easing: r.transitionEffect,
              complete: function () {
                n("." + r.dropdownClass).remove();
                u.removeClass("active");
                f = 0;
                r.callOnCompleteHide();
              },
            })
          : (n("." + r.dropdownClass).remove(),
            u.removeClass("active"),
            (f = 0),
            r.callOnCompleteHide());
      }),
      (l = function () {
        v(function () {
          var t, i;
          if (
            (n.each(n("." + r.elemSelector), function (t, i) {
              if (n(i).hasClass("active"))
                return (
                  n("." + r.dropdownClass).remove(),
                  n(i).removeClass("active"),
                  r.callOnCompleteHide(),
                  !1
                );
            }),
            (t = u.find("." + r.descriptionClass).html()),
            (i = u.next()),
            typeof i.position() != "undefined"
              ? n(
                  '<div class="' +
                    r.dropdownClass +
                    '" style="display:none"><div class="' +
                    r.dropdownContentClass +
                    '"><div class="' +
                    r.arrowClass +
                    '"></div>' +
                    t +
                    "</div></div>"
                ).insertAfter(o(u, i))
              : n(
                  '<div class="' +
                    r.dropdownClass +
                    '" style="display:none"><div class="' +
                    r.dropdownContentClass +
                    '"><div class="' +
                    r.arrowClass +
                    '"></div>' +
                    t +
                    "</div></div>"
                ).insertAfter(u),
            r.useSlideDown)
          )
            n("." + r.dropdownClass).slideDown({
              duration: r.slideDownSpeed,
              easing: r.transitionEffect,
              complete: function () {
                n("." + r.arrowClass).show();
                n("." + r.arrowClass).css(
                  "left",
                  u.position().left + u.outerWidth() / 2
                );
                u.addClass("active");
                r.callOnCompleteShow();
              },
            });
          else {
            n("." + r.dropdownClass).show();
            n("." + r.arrowClass).show();
            n("." + r.arrowClass).css(
              "left",
              u.position().left + u.outerWidth() / 2
            );
            u.addClass("active");
            r.callOnCompleteShow();
            return;
          }
        });
      }),
      (o = function (n, t) {
        return "undefined" != typeof t.position() &&
          n.position().top === t.position().top
          ? o(t, t.next())
          : n;
      }),
      (y = function () {
        u = n(this);
        u.hasClass("active") ? c() : l();
      }),
      n(t).ready(function () {
        h();
      }),
      n(t).resize(function () {
        p();
      }),
      this.each(function () {
        var t;
        if (
          ((t = n(this)
            .find("." + r.descriptionClass)
            .html()),
          typeof t == "undefined" ||
            t.length === 0 ||
            n(this).hasClass(r.disableDropdownClass))
        )
          return !0;
        n(this).click(y);
      })
    );
  };
})(jQuery, window, document);
