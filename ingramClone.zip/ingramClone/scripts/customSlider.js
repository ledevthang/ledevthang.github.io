function setCardCount() {
  var n = $(window).width();
  n <= 600 && (cardPerRow = 1);
  n > 600 && n <= 768 && (cardPerRow = 2);
  n > 768 && n <= 991 && (cardPerRow = 3);
  n > 991 && (cardPerRow = 3);
}
function initReWriteSliderFunc() {
  $(".CarouselID2").each(function () {
    reWriteSlider($(this));
  });
}
function reWriteSlider(n) {
  var u = [],
    t,
    i,
    r;
  for (
    n.find("[class*='col']").each(function () {
      $(this).removeClassStartingWith("col");
      cardPerRow == 4
        ? $(this).addClass("col-4 d-flex")
        : cardPerRow == 3
        ? $(this).addClass("col-4 d-flex")
        : cardPerRow == 2
        ? $(this).addClass("col-6")
        : cardPerRow == 1 && $(this).addClass("col-12");
      u.push($(this));
    }),
      n.find(".carousel-inner").html(u),
      t = n.find(".carousel-inner > div"),
      i = 0;
    i < t.length;
    i += cardPerRow
  )
    t.slice(i, i + cardPerRow).wrapAll(
      "<div class='carousel-item'><div class='container mb-3'><div class='row'></div></div></div>"
    );
  n.carousel("dispose");
  r = !1;
  t.length > cardPerRow &&
    cardPerRow > 2 &&
    ((r = 5e3), n.removeClass("noarrow-slider-lg"));
  n.carousel({ interval: r })
    .on("slide.bs.carousel", function () {})
    .on("slid.bs.carousel", function () {
      $(this).find(".carousel-item").removeClass("next-to-slide");
      $(this).find(".active").next().addClass("next-to-slide");
    });
  n.find(".carousel-item:first-child")
    .addClass("active")
    .next()
    .addClass("next-to-slide");
  t.length <= cardPerRow &&
    (n.find(".carousel-item .row").addClass("justify-content-center"),
    n.find(".carousel-control").hide());
}
function toggleDropdown(n) {
  $(".dropdown-menu.show").removeClass("show");
  const t = $(n.target).closest(".dropdown"),
    i = $(".dropdown-menu", t);
  $(window).width() >= 1024 &&
    setTimeout(
      function () {
        const r = n.type !== "click" && t.is(":hover");
        i.toggleClass("show", r);
        t.toggleClass("show", r);
        $('[data-toggle="dropdown"]', t).attr("aria-expanded", r);
      },
      n.type === "mouseleave" ? 30 : 0
    );
}
var cardPerRow;
$.fn.removeClassStartingWith = function (n) {
  return (
    $(this).removeClass(function (t, i) {
      return (i.match(new RegExp("\\S*" + n + "\\S*", "g")) || []).join(" ");
    }),
    this
  );
};
$(window).on("resize", function () {
  setCardCount();
  initReWriteSliderFunc();
});
$(document).ready(function () {
  setCardCount();
  initReWriteSliderFunc();
  $(".CarouselID2").on("touchstart", function (n) {
    var t = n.originalEvent.touches[0].pageX,
      i = !1;
    $(this).find(".active").next().removeClass("next-to-slide");
    $(this).on("touchmove", function (n) {
      i = !0;
      var r = n.originalEvent.touches[0].pageX;
      Math.floor(t - r) > 5
        ? $(this).carousel("next")
        : Math.floor(t - r) < -5 && $(this).carousel("prev");
    });
    $(".CarouselID2").on("touchend", function () {
      $(this).off("touchmove");
    });
  });
  $("body")
    .on("mouseenter mouseleave", ".navbar-nav .dropdown", toggleDropdown)
    .on("click", ".navbar-nav .dropdown-menu a", toggleDropdown);
});
