$(document).ready(function () {
  if ($("body").hasClass("InternetExplorer")) {
    $(".login-mob").find("button").attr("data-toggle", "dropdown");
    $(".login-mob")
      .find("a.nav-link.dropdown-toggle")
      .addClass("mr-0")
      .attr("aria-haspopup", "true")
      .attr("aria-expanded", "false")
      .changeElementType("span");
    var n = $(".login-dropdown");
    n.appendTo(".login-mob");
  }
  $(".location-desktop").length == 0 &&
    ($(".navbar-nav").append(
      '<li class="nav-item dropdown location-desktop"></li> <li class="nav-item dropdown login-desktop">' +
        $(".login-mob").find("button").html() +
        "</li>"
    ),
    $(".location-now")
      .find("a")
      .clone()
      .removeAttr("id")
      .addClass("location-now nav-link dropdown-toggle")
      .appendTo(".location-desktop"),
    $('<i class="fa fa-chevron-down header-mob-button"></i>').appendTo(
      ".login-desktop > a"
    ),
    $(".navbar-nav")
      .find(".dropdown-menu")
      .each(function () {
        $(this).wrapInner("<div class='subMenu-wrapper'></div>");
      }));
  $(".have-popOver .card").click(!1);
  $(".have-popOver .card-footer a").click(function () {
    $(this).closest(".have-popOver").click();
  });
  $(".have-popOver").dropdownLayer({
    elemSelector: "have-popOver",
    containerClass: "popOver-wrapper",
    descriptionClass: "popOver-description",
    arrowClass: "js-dropdown-arrow",
    dropdownClass: "js-dropdown",
    dropdownContentClass: "js-dropdown-content",
    disableDropdownClass: "js-dropdown-disable",
    useSlideUp: !0,
    slideUpSpeed: 200,
    useSlideDown: !0,
    slideDownSpeed: 200,
  });
}),
  (function (n) {
    n.fn.changeElementType = function (t) {
      var i = {};
      n.each(this[0].attributes, function (n, t) {
        i[t.nodeName] = t.nodeValue;
      });
      this.replaceWith(function () {
        return n("<" + t + "/>", i).append(n(this).contents());
      });
    };
  })(jQuery);
