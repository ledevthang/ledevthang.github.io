//To Hide and show carousel slides
function ShowSection(panel, show) {
  if (panel == 2 && show == "true") {
    //$("Panel2").add();
    //$("indicator2").add();
  } else if (panel == 2 && show == "false") {
    $("#Panel2").remove();
    $("#indicator2").remove();
  }

  if (panel == 3 && show == "true") {
    //$("Panel3").add();
    //$("indicator3").add();
  } else if (panel == 3 && show == "false") {
    $("#Panel3").remove();
    $("#indicator3").remove();
  }

  if (panel == 4 && show == "true") {
    //$("Panel4").add();
    //$("indicator4").add();
  } else if (panel == 4 && show == "false") {
    $("#Panel4").remove();
    $("#indicator4").remove();
  }

  if (panel == 5 && show == "true") {
    //$("Panel5").add();
    //$("indicator5").add();
  } else if (panel == 5 && show == "false") {
    $("#Panel5").remove();
    $("#indicator5").remove();
  }

  if (panel == 6 && show == "true") {
    //$("Panel6").add();
    //$("indicator6").add();
  } else if (panel == 6 && show == "false") {
    $("#Panel6").remove();
    $("#indicator6").remove();
  }
}

function ShowHideIndicators() {
  $("#Previous").remove();
  $("#Next").remove();
  $("#indicator1").remove();
  $("#indicator2").remove();
  $("#indicator3").remove();
  $("#indicator4").remove();
  $("#indicator5").remove();
  //$('#indicator6').remove();
}
